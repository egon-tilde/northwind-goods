import handlerMod from './server/handler.cjs';

const { handle, routeFromUrl } = handlerMod;

async function run(request) {
  const route = routeFromUrl(new URL(request.url).pathname) || '';
  const [status, obj] = await handle({
    method: request.method,
    route,
    headers: request.headers,
    getBody: () => request.json().catch(() => ({})),
    root: process.cwd(),
  });
  return new Response(JSON.stringify(obj), {
    status,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
  });
}

export const GET = run;
export const POST = run;
