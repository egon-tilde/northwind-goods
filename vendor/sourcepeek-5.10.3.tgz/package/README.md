# Sourcepeek 🔥

Click any element of your app in dev mode and see the source file, line and component it came from, the component chain around it, where it is used, its props and state, its git history, and AI insights. Alt+click jumps straight into your editor. Describe a change in plain words and Sourcepeek either previews it as CSS or writes it into your real source code, with a diff and one-click undo.

Works with **React (Vite)**, **Next.js** (webpack and Turbopack), **Vue 3**, **Svelte / SvelteKit** and **Angular** (16+, Angular CLI).

## Quick start

```bash
npm i -D sourcepeek@latest
npx sourcepeek setup
```

Then render `<Sourcepeek />` once, anywhere in your app, and restart your dev server.

**Next.js — App Router** (`app/layout.tsx`, works in the Server Component layout)

```tsx
import Sourcepeek from 'sourcepeek/react';

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        {children}
        <Sourcepeek />
      </body>
    </html>
  );
}
```

**Next.js — Pages Router** (`pages/_app.tsx`)

```tsx
import Sourcepeek from 'sourcepeek/react';

export default function App({ Component, pageProps }) {
  return (
    <>
      <Component {...pageProps} />
      <Sourcepeek />
    </>
  );
}
```

**React + Vite** (`src/App.jsx`)

```jsx
import Sourcepeek from 'sourcepeek/react';

export default function App() {
  return (
    <>
      {/* your app */}
      <Sourcepeek />
    </>
  );
}
```

**Vue 3** (`src/App.vue`)

```vue
<script setup>
import Sourcepeek from 'sourcepeek/vue';
</script>

<template>
  <!-- your app -->
  <Sourcepeek />
</template>
```

**Svelte / SvelteKit** (`src/App.svelte` or `src/routes/+layout.svelte`)

```svelte
<script>
  import Sourcepeek from 'sourcepeek/svelte';
</script>

<slot />
<Sourcepeek />
```

**Angular** (`src/app/app.config.ts`, or the `providers` of your `AppModule`)

```ts
import { provideSourcepeek } from 'sourcepeek/angular';

export const appConfig: ApplicationConfig = {
  providers: [
    provideSourcepeek(),
    // …
  ],
};
```

Click **“Sourcepeek: OFF”** in the bottom-right corner to turn inspect mode on, hover to highlight, click an element to inspect it. `Esc` closes panels and exits inspect mode.

## New in 5.10.3

- **Change with AI never adds comments** — not to code, markup or CSS. The AI is told not to write any, and every comment it adds anyway (`//`, `/* */`, `{/* */}` in JSX, `<!-- -->`, CSS inside styled-components and Angular inline templates/styles) is removed before the change is previewed or written. Comments already in your files are kept. Live CSS previews are comment-free too.

## New in 5.10.2

- **More → opens docked to the side**, so the page stays visible and usable. Click **Expand** at the top for the full view.
- **Renders & state catches every prop change**: a value changed deeper than the preview shows (`items changed inside [{…}, {…}]`), and a prop that arrives as a new object or function with the same contents (`onSelect new reference, same value (prop)`) — the usual reason a `memo()` child re-renders. Renders whose only changes are new references count as “nothing changed”.

## Unreleased

The **More →** view is now: **Summary → Change with AI → Renders & state → Network → Storage → Accessibility → Meta tags → Refactor → Report**.

- **Meta tags** — the SEO check (formerly the **Page** button next to the Sourcepeek toggle) is now an accordion in the More view. See [Meta tags](#meta-tags-seo).
- **Storage** shows everything the page stores in one list — no *Whole page* tab. The component's own keys come first in each area.
- **Network** always lists every other request on the page below the component's own — no *Show all* button.

## New in 5.10

The **More →** view is now: **Summary → Change with AI → Renders & state → Network → Storage → Accessibility → Refactor → Report**.

- **Storage**: the localStorage, sessionStorage and Cache Storage keys a component reads and writes, found in the code and captured live. A *Whole page* tab lists everything the page stores. You can view, edit and remove values; secrets are masked. See [Storage](#storage).

## New in 5.8

- **New page / route** in *Change with AI* — *add new route / page, new component on it saying hihi* now creates the page where your router expects it (Next.js `app/` or `pages/`, SvelteKit, Nuxt, Remix, TanStack, or a page + route entry for React Router / Vue Router / Angular). See [New pages and routes](#new-pages-and-routes).
- **Randomise** — on every request in *Network*: the AI writes realistic data in the shape the app expects, mocks the request with it and shows it on the page. See [Mocking requests](#mocking-requests).
- **Clearing mocks reloads the page** when the mock had already answered, so the real data comes back; the mock bar has a **Reload** button.

## New in 5.7

The **More →** view is now: **Summary → Change with AI → Renders & state → Network → Accessibility → Refactor → Report**.

- **Renders & state** — a timeline of the component you opened: `#14 · 12:04:31 · price 120 → 99 (prop) · isOpen false → true (state)`. Renders where nothing changed are listed too, which is how you spot wasted re-renders. See [Renders & state](#renders--state).
- **Accessibility** — checks the clicked element and its component, with the file and line of every finding and a **Fix with AI** button. The header shows the count without opening it (`Accessibility · 3 issues`). See [Accessibility](#accessibility).
- **Page check** — SEO basics for the whole page (title, meta description, h1s, canonical, Open Graph, `lang`). Now the **Meta tags** section of the More view; see [Meta tags](#meta-tags-seo).
- **Mock this** — on every request in *Network*. Mocks keep answering after the panel closes, so a bar at the bottom of the page shows `2 mocks active · Clear all` and mocked requests carry a **MOCK** badge. See [Mocking requests](#mocking-requests).

## Renders & state

*More → Renders & state* follows one component — the one you opened — from the moment you open the section until you close the More view. Only the last 100 entries are kept, and nothing is tracked while the section is closed, so the app doesn't slow down.

Each entry lists what changed, with the source of every change:

```
#14 · 12:04:31 · price 120 → 99 (prop) · isOpen false → true (state)
#15–#22 · 12:04:33 · 8× rendered, nothing changed
#23 · 12:04:35 · filters changed inside {range: {…}} (prop)
#24 · 12:04:36 · onSelect new reference, same value (prop)
```

“Nothing changed” rows are the interesting ones: the component ran again with the same props and state — usually a parent re-render, or a new object/function passed as a prop. Consecutive ones are merged. **Current values** shows the props and state right now; **Copy** puts the timeline on the clipboard for a ticket or an AI chat.

“Render” means something different in each framework, so it is labelled for what it is:

| Framework | What is counted | How |
| --- | --- | --- |
| React | **Re-renders** | The React DevTools commit hook, checked on every commit (*exact*). State hooks are named from your source (`const [isOpen, setIsOpen] = useState()`), up to the first custom hook. |
| Vue | **Component updates** | The component's `updated` hook: Vue re-ran its render because something it uses changed. |
| Angular | **Change detection checks** | One per change detection cycle (via `provideSourcepeek()`). Angular *checks* the component's bindings every cycle; a check doesn't mean anything re-rendered. For OnPush components the count is an upper bound. |
| Svelte 5 | **DOM updates** (*rough*) | Svelte 5 has no runtime component instance, so its state can't be read from outside. Sourcepeek shows the changes that reached the component's DOM (`text "Only 120 EUR" → "Only 99 EUR"`). |

React needs the DevTools hook to exist before `react-dom` loads. React Fast Refresh (Vite, Next.js, CRA) and the React DevTools extension both create it, and the Vite plugin adds it to `index.html` as well. In any other setup, Sourcepeek samples the component every 250 ms instead (marked *sampled*); for exact counts, import the hook first:

```js
import 'sourcepeek/react-hook'; // first line of your entry file, before React
```

## Accessibility

*More → Accessibility* checks the clicked element and its component, including the components it renders:

- images without alt text, or with alt text like `image.png`
- buttons and links with no text (icon-only buttons without `aria-label`)
- form fields without a label (a placeholder isn't one)
- colour contrast below WCAG AA (4.5:1, or 3:1 for large text), computed from the real colours on the page
- skipped heading levels (`h2 → h4`) and empty headings
- elements with a click handler that the keyboard can't reach (`<div onClick>`), positive `tabindex`, focusable content inside `aria-hidden`

Each finding links to the file and line that wrote the element (hover a finding to see it on the page, **Show** scrolls to it). **Fix with AI** sends the finding, with that location, to *Change with AI*: you get a preview (a diff, or live CSS for contrast) and nothing is written until you click *Apply to code*. Automated checks find only part of the problems — try the page with Tab and a screen reader too.

## Meta tags (SEO)

Inspect any element → **More →** → **Meta tags** checks SEO basics for the whole page (it's the same for every component). The header shows the result while collapsed (`Meta tags · 2 problems`); **Re-check** runs it again.

- **Title** — present, about 30–60 characters
- **Meta description** — present, about 70–160 characters
- **h1** — exactly one (**Show** highlights them)
- **Canonical** — one absolute `<link rel="canonical">`
- **Open Graph** — `og:title`, `og:description`, `og:image`, `og:url`, `og:type`
- **`lang`** on `<html>`
- a `noindex` robots tag, if there is one

Sourcepeek also loads the HTML your server sends for the page and flags values that exist only after JavaScript runs — crawlers and link previews that don't run JavaScript won't see them.

## New in 5.6

- **Angular support.** Inspect, Alt+click, component chain, inputs and state, *Used in*, Network and *Change with AI* work in Angular CLI projects (`ng serve`). See [Angular](#angular).
- **Correct imports for new components.** Svelte and Vue components are always default-imported with their extension (`import PriceTag from './PriceTag.svelte'`); a named import (`import { PriceTag } …`), a missing extension or a component used in the markup but never imported is caught before anything is written, and the AI fixes it. Angular components are wired up completely: TypeScript import, the standalone `imports` array (or the NgModule), `templateUrl` / `styleUrl` files.
- **Expand / Dock to side** are always shown in the **More →** view, as a two-button switch.
- The inspect panel shows the component's props only; its state moved to the **More →** view.

## From UI to code (new in 5.5)

| Shortcut | What it does |
| --- | --- |
| **Alt + click** (⌥ + click) | Opens the element's file at the right line in your editor. No panel, works with inspect mode on or off. Hold Alt to see what you'd open. |
| **Alt + Shift + click** | Copies `src/components/Button.tsx:12` to the clipboard, for Slack, a ticket or an AI chat. |

The inspect panel now shows:

- **Component chain** — `App › Layout › Header › Button`. Each crumb is clickable (inspect that component) and Alt+click on a crumb opens it. Hover a crumb to highlight it on the page. Works with React (including Server Components in Next.js), Vue, Svelte 5 and Angular.
- **Used in** — the element lives in `Button.tsx`, but where is *this* `<Button>` rendered? Sourcepeek shows the call-site (`Page.tsx:42`), so you can change the props passed to it. Vue shows the parent file.
- **Props** — the props the component was rendered with (Angular: its inputs). Collapsed by default. Its current state (React hooks/class state, Vue setup state, Angular fields), and how both change over time, is in **More → Renders & state**.
- **Text from translations** — click on text that comes from an i18n file and Sourcepeek shows the key (`home.cta`), the translation file and line, and where the key is used. Works with JSON and YAML translation files in folders like `locales/`, `i18n/`, `messages/`, including placeholders (`Hello, {name}!`).
- **Copy file:line** and **Open in …** — the editor you pick from the ▾ menu is remembered and also used by Alt+click. VS Code, Cursor, Windsurf, VS Code Insiders, Zed, WebStorm and IntelliJ IDEA are supported. Set a default for the whole team with `SOURCEPEEK_IDE=cursor` in `.env`.

On Linux, some window managers use Alt+drag to move windows and swallow Alt+click; disable that shortcut in your desktop settings if Alt+click does nothing.

## One-click bug report

Open **More → Report** on any element. Sourcepeek collects everything a developer needs and gives you one Markdown block to paste into GitHub, Jira, Linear, Slack or an AI chat. Developers get the exact file and line instead of a description:

- **Screenshot** of the visible page with the element outlined in red. It is rendered from the page (no permission prompt) and kept in memory only — nothing is saved automatically. Use **Copy screenshot** or **Download** to attach it to a ticket. **Capture screen** takes a pixel-perfect shot through the browser's screen-share prompt instead.
- **Component, file and line**, where it's rendered from, and the component chain
- **Props and state** of the component when the report was made
- **Page URL**, plus the git branch and who last changed that line
- **Failed requests** (4xx/5xx and network errors) with request payloads, responses, and the file that sent them
- **Console errors**: `console.error`, uncaught errors, unhandled promise rejections and resources that failed to load, with stacks
- **Browser and viewport**: browser, OS, size, pixel ratio, light or dark mode
- **The last 30 seconds of clicks** before you opened Sourcepeek, each with the file and line of the clicked element. Clicks survive a full page reload.

Passwords, tokens, API keys, cookies and similar fields are replaced with `[redacted]` in payloads, responses, URLs, props and console messages. `.sourcepeek/` contains its own `.gitignore`, so screenshots are never committed. Only the 50 newest are kept, and they are saved only by your local dev server.

## AI features (optional)

Add a key for any supported provider to `.env.local` (or `.env`) in the project root. Sourcepeek picks it up automatically:

| Provider | Key | Default model |
| --- | --- | --- |
| OpenAI | `OPENAI_API_KEY` | `gpt-4.1-mini` |
| Claude (Anthropic) | `ANTHROPIC_API_KEY` | `claude-haiku-5-5` |
| Gemini | `GEMINI_API_KEY` or `GOOGLE_GENERATIVE_AI_API_KEY` | `gemini-3.8-flash` |
| Mistral | `MISTRAL_API_KEY` | `mistral-small-latest` |
| Groq | `GROQ_API_KEY` | `llama-3.3-70b-versatile` |
| DeepSeek | `DEEPSEEK_API_KEY` | `deepseek-chat` |
| OpenRouter | `OPENROUTER_API_KEY` | `openrouter/auto` |
| Ollama (local) | none, detected when running | first installed model |

If several keys are present, the first one in this table wins. Optional overrides:

```
# force a provider: openai, anthropic, gemini, mistral, groq, deepseek, openrouter, ollama
SOURCEPEEK_AI_PROVIDER=anthropic
# use a different model
SOURCEPEEK_AI_MODEL=claude-sonnet-5-5
```

Any other OpenAI-compatible service (LM Studio, Together, vLLM, Azure gateways…) works with `SOURCEPEEK_AI_BASE_URL`, `SOURCEPEEK_AI_MODEL` and optionally `SOURCEPEEK_AI_API_KEY`. `SOURCEPEEK_OPENAI_MODEL` from older versions still works.

Keys are read on each request, so no restart is needed. They never leave your machine except to call the provider. AI answers show which provider and model produced them.

Sourcepeek can only use API keys. Chat subscriptions (ChatGPT Plus, Claude Pro, Copilot, Cursor) don't include API access.

In the **More →** view (switch between **Expand** and **Dock to side** at the top), *Summary*, *Change with AI*, *Refactor*, *Network* and *Storage* are collapsible sections. *Summary* describes the component and lists its *Potential issues* in the same section; *Refactor* requests its suggestion as soon as you open it. Both are only requested when opened, and a successful answer is kept until the view closes.

The round **$** button at the top of the More view shows what the AI model in use has cost so far: requests, input/output tokens and an estimated dollar total. Sourcepeek counts the tokens of every AI call it makes and keeps the totals per model in `.sourcepeek/usage.json` (git-ignored), so it covers Sourcepeek's own calls in this project, not your whole provider account. Built-in prices cover the default models; for any other model set `SOURCEPEEK_AI_PRICE` (see the table below). OpenRouter reports the exact cost itself, and Ollama is free. Without a key, each AI section shows `Missing AI key in .env` (*Network* and *Storage* need no key).

## Change with AI (new in 5.5)

Inspect an element → **More →** → **Change with AI**. Write what you want in plain words and click **Preview**. Sourcepeek detects what kind of change it is, so there is no mode to pick:

- **Visual changes** are previewed live as CSS injected into the page.
- **Changes CSS can't do** (text, logic, a new component) are previewed as a diff.

Nothing is written yet. Every result appears in the **Changes** list with the same three buttons:

| Button | On a preview | On an applied change |
| --- | --- | --- |
| **Diff** | shows the injected CSS, or the code diff | shows the code diff |
| **Apply to code** | writes it into your real source files; your dev server hot-reloads it | — |
| **Undo** | removes the live CSS, or discards the diff (nothing was written) | restores the exact previous files and removes new ones |

Applying can touch the clicked component's file, the stylesheets it imports (CSS Modules, `.css`, `.scss`, `.sass`, `.less`), its styled-components/emotion styles module, the file where the component is used, and new component files next to it.

### What kind of change is it?

Before asking for any code, Sourcepeek works out what you asked for:

| Kind | Example | Preview shows | Apply to code does |
| --- | --- | --- | --- |
| **Style** | *make the title red*, *more padding on mobile* | CSS, live | edits only the styling layer (see below) |
| **Reorder** | *put section 1 after section 2* | CSS `order`, live | moves the markup |
| **Code** | *change the text to "Buy now"*, *open the link in a new tab* | shows the diff | edits markup / logic |
| **Style + code** | *make it red and add a loading state while it submits* | shows the diff | does both, each in the right place |
| **New component** | *extract the price into a PriceTag component* | shows the diff | creates the component file(s) and uses it |
| **New page / route** | *add a new page /hihi with a component saying "hihi"* | shows the diff | creates the page where your router expects it (plus its components) and registers the route if routes are declared in code |

Clear requests are classified instantly by rules; only unclear ones cost one small extra AI call. The result is shown as a badge with the reason (*Code change — needs code (“change the button text”)*). If it guessed wrong, pick the kind yourself in the **Auto-detect** menu next to the button.

### Where the change lands

The panel shows how the clicked element is styled (*Styled with: styled-components · Card.styles.ts*), and the AI is told exactly where to make style changes:

| The element is styled with | Style changes go to |
| --- | --- |
| **styled-components / Emotion / Linaria / Stitches** | the template literal of that styled component (`<S.Title>` → `Card.styles.ts:8`), reusing theme values and transient `$props` |
| **SCSS / Sass / Less / CSS Module** | the class rule the element uses (`styles.primary` → `.primary` in `Button.module.scss`), reusing your Sass `$variables` and `@mixin`s |
| **Global SCSS / CSS** | the rule for that class in the imported stylesheet |
| **Tailwind (v3/v4) / UnoCSS** | utility classes in `className`, replacing conflicting ones, with `cn()` / `clsx()` / `cva` as the file uses them |
| **Vue / Svelte `<style>`** | the component's own `<style>` block, keeping `lang`, `scoped`, `module` |
| **MUI `sx`, Emotion `css` prop, styled-jsx, inline** | that prop / block |

Detection looks at the clicked element first, then its component, then the project's `package.json`, so a Tailwind project with one SCSS-module component still gets SCSS for that component. Sass partials the stylesheet `@use`s are shown to the AI **read-only**, so it uses `$primary` instead of a hard-coded colour without changing shared tokens.

Clicking an element rendered by a styled component (or by a library component that forwards `data-*` props) now jumps to where it's used, e.g. the `<S.Title>` line, instead of the nearest plain HTML ancestor.

### New components

> extract the price into its own PriceTag component

The AI creates the new file(s) and imports and renders the component in the one you clicked. It follows the clicked component's conventions: file extension, folder-per-component layout, default vs. named export, typed props in TypeScript, and the same styling approach (a `PriceTag.module.scss`, a `PriceTag.styles.ts`, Tailwind classes, or a `<style>` block).

| Framework | How the new component is imported |
| --- | --- |
| React / Next.js | default or named, matching how the clicked component exports itself; no `.tsx` / `.jsx` extension |
| Svelte | `import PriceTag from './PriceTag.svelte'` — always a default import, always with `.svelte` (Svelte 5 runes or `export let`, like the clicked component) |
| Vue | `import PriceTag from './PriceTag.vue'` — always a default import, always with `.vue`; also registered in `components` when the clicked component uses the Options API |
| Angular | `import { PriceTag } from './price-tag/price-tag'`, added to the standalone component's `imports` array (or to the NgModule), used by its selector `<app-price-tag />`; file names, class suffix, `input()` vs `@Input()` follow the clicked component | New files may only be created in the clicked component's folder, or next to it in a folder-per-component project, at most 4 files, never overwriting an existing file. Undo deletes them again, including the folder if it's empty.

### New pages and routes

> add new route / page, new component on it saying hihi

A page has to live where the router looks for pages — usually not the clicked component's folder — so Sourcepeek detects the project's routing and tells the AI exactly where the files go:

| Routing | A new page is |
| --- | --- |
| Next.js App Router | `app/<route>/page.tsx` (next to existing pages, inside the same route group / `[segment]`); components in `components/` |
| Next.js Pages Router | `pages/<route>.tsx` |
| SvelteKit | `src/routes/<route>/+page.svelte`; components in `src/lib`, imported via `$lib` |
| Nuxt | `pages/<route>.vue` (and `<NuxtPage />` added to `app.vue` if it is missing); components in `components/` (auto-imported) |
| Remix / React Router 7 | `app/routes/<route>.tsx`, plus a `route(…)` entry when `app/routes.ts` lists routes |
| TanStack Router (file-based) | `src/routes/<route>.tsx` with `createFileRoute` |
| React Router, wouter, TanStack (code-based) | a component in `src/pages/`, **and** a route entry + import in the file that declares the routes (found automatically) |
| Vue Router | a view in `src/views/`, **and** a route in `src/router` |
| Angular | a component in its own folder, **and** a route in `app.routes.ts` / `app-routing.module.ts` |

Before anything is written Sourcepeek checks that a route file was really created (file-based routing) or that the router file really got the new route (routing in code); otherwise the AI gets the problem back and retries. Existing routes are kept and a catch-all route stays last. A project without any router gets a clear message instead of a half-made page. Requests like *add a new page*, *create a page called settings*, *new route "/hihi"* are detected automatically; you can also pick **New page / route** in the menu.

### Apply to code

> make this button red and add a loading state while it submits

Sourcepeek already knows the file, line, component, call-site, props and rendered HTML of what you clicked, so you don't have to explain which element you mean.

Safety net:

- **Dev server only.** The endpoint that writes files exists only on your local dev server (`vite dev`, `next dev`). Sourcepeek itself runs in production builds too, but *Apply to code* is never available in production builds, `vite preview`, `next start` or on Vercel.
- **Local only.** Write requests are accepted only from this computer, even if the dev server is exposed with `--host`. Set `SOURCEPEEK_ALLOW_REMOTE_EDITS=1` to allow other devices on your network.
- **Limited scope.** Only the files listed above, inside the project, never `node_modules`. New files only for a new component (only in the component's folder) or a new page (only in the routes / pages folder and the components folder), never overwriting anything. Shared Sass partials are read-only.
- **Will it run?** After the syntax check, Sourcepeek rejects changes that parse but would crash: a component used in JSX or in Svelte / Vue markup but never imported, an import path that doesn't exist or ends in `.ts`/`.tsx` (unless `allowImportingTsExtensions` is on), a `.svelte` / `.vue` import without its extension, a default import of a file without a default export (and vice versa — including `import { X } from './X.svelte'`), in Next.js App Router hooks or `onClick` added to a Server Component, or a new interactive component without `"use client"`, and in Angular a new selector used in a template whose component doesn't import (or whose NgModule doesn't declare) the new component, or a `templateUrl` / `styleUrl` that doesn't exist. A request to *add* a component may not delete the surrounding markup (only *extract / move / replace* requests may). The AI gets the exact problem back and up to 3 attempts in total.
- **Syntax check first.** Every changed or new file is parsed (Babel for JS/TS/JSX, the CSS inside styled-components/emotion templates, Vue's and Svelte's own compilers, Angular templates — `.html` and inline — with the project's `@angular/compiler`, their `<style lang="scss">` blocks, and `postcss-scss` / `postcss-less` / `sass` when your project has them, a brace check otherwise) before anything is written. If it doesn't parse, the AI retries with the error; if it still fails, *nothing is written*.
- **Diff and Undo.** Each change lists its files with `+added −removed`, a full diff, and **Undo**. The previous version is stored in `node_modules/.cache/sourcepeek/edits`, so Undo works after a page reload or a dev server restart. If the file was changed again afterwards (by you or another tool), Undo warns you instead of overwriting it, with an *Undo anyway* option.
- **Error watch.** For 10 seconds after a change, Sourcepeek watches for a Vite/Next.js error overlay or an uncaught error. If one appears, a red bar offers **Revert change**. This works even if the change crashed the whole app.
- **No comments added.** Comments the AI writes are stripped from every edit and new file (existing comments stay).
- **Review first, always.** Code changes are previewed as a diff before anything is written; **Apply to code** writes them, **Undo** discards them.

A green bar at the bottom of the page shows the last change with an **Undo** button. The *Changes* list belongs to the browser tab and the current dev-server run: it survives page reloads, but starts empty after you restart the dev server (older changes' undo data stays in `node_modules/.cache/sourcepeek/edits`). Code previews that were never applied expire after 15 minutes. **Clear applied** removes applied changes from the list without touching your files.

Turn the feature off with `SOURCEPEEK_EDITS=0`.

### Preview

For visual requests, Sourcepeek sends a compact outline of the visible page plus your clicked element to the AI, gets back CSS, and injects it as `<style id="sourcepeek-live-styles">`. Requests stack, so you can follow up with "even bigger" or "undo the red". Hashed class names from styled-components and Emotion are kept out of the selectors, so a preview survives the next hot reload.

For requests CSS can't do (text, logic, a new component), Preview shows the code diff instead. Nothing is written until you click **Apply to code**. If *Apply to code* is unavailable (e.g. a request from another device), Preview falls back to CSS for the visual part and says what it skipped.

- **Apply to code** on a preview item turns it into a real change: the AI translates the previewed CSS into your project's styling and writes it to the source. The preview item is removed once it's written.
- Each preview can be removed with **Undo** or inspected via **Diff**.
- Preview changes survive a page reload within the same tab (sessionStorage) and are never written to your files unless you click *Apply to code*.

## Network

Inspect an element → **More →** → **Network** lists the HTTP requests that component makes or can make. No AI key needed.

- **From the code.** Sourcepeek reads the component and the hooks / API modules it imports (two levels deep, only the exports it actually uses) and finds `fetch`, `axios` and axios-style clients (`api.get(...)`, `axios.create({ baseURL })`), `ky`, `ofetch` / `$fetch` / `useFetch`, `useSWR`, `XMLHttpRequest` and `EventSource`. Each one shows its method, URL (dynamic parts as `{id}`) and the function and line it is called from.
- **Live.** `fetch` and `XMLHttpRequest` are recorded on the page while Sourcepeek is mounted. A captured request is attached to the endpoint whose URL it matches, or to the component when its call stack goes through the component's file. Every other request the page made is listed below, under *Other requests on this page*. Status, timing, the payload that was sent and the response are shown.
- **GET** shows the response payload: the live one once the request ran, otherwise the expected shape from the TypeScript type (`axios.get<User[]>`, `res.json() as User`, `Promise<User>` return types). **Send request** fires a GET from the panel.
- **POST / PUT / PATCH / DELETE** show an example payload inferred from the code (object literals, `JSON.stringify(...)`, `URLSearchParams`, `FormData`), next to the last payload actually sent.
- **Copy cURL** builds a ready-to-run command from the last captured request, or from the code. Tick *cookies in cURL* to include this page's cookies for endpoints behind a session.

### Mocking requests

**Mock this** on any request answers it with a response you write — status, body, content type, a delay, or a network error. The body starts as the last real response (or the expected shape from the types). Your server is not called.

**Randomise** (next to *Mock this*) asks the AI for realistic data for the request and mocks it straight away. The AI gets the known shapes of the response (the last real answer, the response type in the code, the current mock), the server route that answers the URL (e.g. `app/api/cart/route.ts`), the code that calls it and the clicked component — so keys, nesting and types stay exactly as the app expects, empty lists (an empty cart) get filled with plausible entries, and totals add up. If the page already loaded the data, Sourcepeek asks it to load again and reloads the tab when it doesn't (mocks survive the reload), so the new data shows right away. Click again for different data. Without an AI key, Randomise falls back to random values in the known shape (`email` gets an e-mail, `createdAt` a date, `price` a price, ids stay unique…). The mock editor has a *Randomise* button too, which fills the body the same way from whatever JSON is in it.

- Matching is by method and path; tick *only with ?…* to also match the query string. `{placeholders}` from the code match any value.
- `fetch` and `XMLHttpRequest` (so axios too) are answered, with the same properties and events as a real response, plus an `x-sourcepeek-mock: 1` header.
- **Mocks keep running after the panel closes.** While any mock is active, a bar at the bottom of the page says `2 mocks active · Reload · Clear all`; click the count to see them and remove one. Mocked requests carry a **MOCK** badge in Network, and bug reports mark them as mocked.
- **Removing a mock brings the real data back.** Mocked data the page already shows doesn't go away by itself, so *Clear all*, *Remove mock* and the × in the bar reload the page when the removed mock had answered requests. *Reload* in the bar reloads at any time (mocks survive it).
- Mocks are kept in sessionStorage: they survive a reload of the tab, but a new tab starts without them. Requests sent before Sourcepeek loads are not mocked.

## Storage

Inspect an element, then open **More →** → **Storage**. It shows what that component keeps in the browser. No AI key needed. The header shows the count while collapsed (`Storage · 3 keys`).

- **From the code.** Sourcepeek reads the component and the hooks and modules it imports (two levels deep, only the exports it actually uses). It finds:
  - `localStorage` / `sessionStorage` calls (`getItem`, `setItem`, `removeItem`, `clear`, and `localStorage.token` / `localStorage['token']`).
  - `useLocalStorage` / `useSessionStorage` / `useStorage` (usehooks-ts, @uidotdev, Mantine, VueUse…) and jotai `atomWithStorage`.
  - zustand `persist({ name })` and redux-persist `persistReducer({ key })` (stored as `persist:<key>`).
  - Cache Storage (`caches.open('v2')`, `cache.put(...)`, `caches.match(...)`).

  Key constants imported from another file (`CART_KEY`, `KEYS.cart`) are resolved. Keys built at runtime keep their dynamic parts as `{userId}` and are matched against the keys actually stored.
- **Live.** Reads and writes are recorded from the moment Sourcepeek loads. A key counts for the component when the call stack goes through the component's file, the same way *Network* attributes requests. Each key shows how often it was read or written, and when.
- **Whole page.** The list always shows every local storage key, session storage key and cache on the page, with sizes and the origin's total usage. Keys the component's code uses (even ones not set yet) come first in each area. *Copy as JSON* copies a whole area, with secrets redacted, which is handy for bug reports. *Clear all* asks for a second click.
- **View, edit, remove.** JSON values are pretty-printed. *Edit* writes the value back in the format the app stored it in (compact JSON stays compact). Sourcepeek then fires a `storage` event, so hooks that listen for one update without a reload. For apps that read storage only on load, a **Reload page** button appears. Cache entries show their status, type and body, and can be deleted one at a time or with their whole cache.
- **Secrets.** Values under keys like `token`, `password` or `apiKey`, and anything that looks like a JWT, are masked. JSON values have only their secret fields redacted. Tick *show secrets* or click *Show* on one value to see them. *Copy value* always copies the real value.
- Sourcepeek's own settings (`sourcepeek:*` keys) are never listed, recorded or cleared.
- Limits:
  - Reads that happen before Sourcepeek loads are not recorded, but their values still show.
  - Caches written by a service worker are listed but not attributed to a component, because the service worker runs outside the page.
  - Cookies and IndexedDB are not covered yet.

## Angular

`npx sourcepeek setup` in an Angular CLI workspace points `ng serve` at a proxy configuration, `sourcepeek.proxy.mjs`, which starts the Sourcepeek backend on a localhost port and forwards `/__sourcepeek/*` to it. A proxy configuration you already had (`proxy.conf.json` / `.js`) is kept and loaded by that file. Then add `provideSourcepeek()` to your providers (see [Quick start](#quick-start)) and restart `ng serve`.

How it finds your code: Angular compiles templates itself, so elements carry no tags. In dev mode Angular knows which component owns an element (`ng.getOwningComponent`) and, since Angular 17.1, the file and line of that component's class. Sourcepeek then finds the element's line inside the component's template (`templateUrl` or inline `template`), using its tag, classes, id, attributes, text and position. So:

- **File** is the template (`product-card.html:4`), **Class** is the component class (`product-card.ts:8`).
- **Used in** is the line in the parent template where the component's selector is used (`app.html:7`).
- **Props** are the component's inputs (signal inputs included), **State** (in *More → Renders & state*) its other fields; injected services are left out.
- Elements inside library components (Angular Material…) resolve to the nearest element written in your own templates.
- *Change with AI* edits the template, the class, the component's stylesheet (`styleUrl` / `styleUrls`, or the inline `styles`), and the NgModule for non-standalone components. New components follow `ng generate component` in the clicked component's style (`price-tag.ts` + `PriceTag`, or `price-tag.component.ts` + `PriceTagComponent`).
- Angular before 17.1 has no class file in the debug info; Sourcepeek looks the class up by name in `src/` instead.
- *Renders & state* counts change detection cycles through `provideSourcepeek()`, which also runs Sourcepeek's own mouse and click listeners outside the Angular zone, so inspecting doesn't trigger change detection.
- Dev server only for locating elements: `ng build` output has no backend and no debug API. `provideSourcepeek()` no longer checks for dev mode, so add it only where you want it.

## What `npx sourcepeek setup` changes

Exactly one config file:

| Project | Change |
| --- | --- |
| Vite (React, Vue, Svelte, SvelteKit) | adds `sourcepeek()` to `plugins` in `vite.config.*` |
| Next.js | wraps the export of `next.config.*` in `withSourcepeek(...)` |
| Angular CLI | sets `proxyConfig` of the `serve` target in `angular.json` to `sourcepeek.proxy.mjs` (created next to it, keeping your existing proxy file) |

It also removes a `babel.config.js` left behind by older sourcepeek/codeview versions (saved as `babel.config.js.sourcepeek-old`), because that file switched Next.js off SWC and broke `next/font`.

Setup is safe to run more than once. Undo it with:

```bash
npx sourcepeek remove
```

### Manual setup

```js
// vite.config.js
import sourcepeek from 'sourcepeek/vite';
export default defineConfig({ plugins: [sourcepeek(), react()] });
```

```js
// next.config.mjs
import { withSourcepeek } from 'sourcepeek/next';
export default withSourcepeek(nextConfig);
```

## How it works

- **Tagging (dev only).** JSX/TSX elements get `data-mf-file`, `data-mf-line` and `data-mf-comp` attributes from a small pre-transform, so Babel is never required and SWC/esbuild keep working. Component usages (`<Button …/>`) get a `data-mf-call="src/Page.tsx:42"` prop, which is how Sourcepeek knows where a component is used. It's a `data-*` attribute, so components that spread their props onto the DOM pass it through harmlessly; `Fragment`, `Suspense`, `StrictMode`, `Profiler` and context providers are skipped. Set `SOURCEPEEK_CALLSITES=0` to turn it off. Vue templates are tagged through Vue's own compiler. Svelte needs no tagging: its dev build already records each element's location.
- **Backend (dev only).** Git, blame and AI endpoints are served at `/__sourcepeek/*` by your own dev server. On Vite it is middleware; on Next.js a small localhost server is started and `/__sourcepeek/*` is rewritten to it. No extra process, no fixed port, no CORS.
- **Angular.** No tagging: the dev-mode debug API (`ng.getOwningComponent`, the class debug info) gives the component and its file; the backend finds the element's line in the template. The backend runs behind the Angular CLI dev-server proxy.
- **UI.** A framework-independent panel rendered inside Shadow DOM, so your app's CSS (Tailwind, resets…) can't affect it and it can't affect your app.

## Production

Sourcepeek runs in production builds the same way it runs on the dev server — there is no development check. **Rendering `<Sourcepeek />` (or adding `provideSourcepeek()`) is the switch**: put it behind your own condition (an env variable, an admin role, a preview deployment…) wherever you don't want it.

```tsx
{process.env.NEXT_PUBLIC_SHOW_SOURCEPEEK === '1' && <Sourcepeek />}
```

Next.js needs the backend route for production builds. `npx sourcepeek setup` creates it (`app/api/sourcepeek/[...path]/route.js`, or `pages/api/sourcepeek/[...path].js`); commit it. Vite needs no extra file.

To turn Sourcepeek off completely in an environment (no tagging, backend answers 404), set `SOURCEPEEK_DISABLE=1`. It is read at build time, so it takes effect on the next build.

| Variable | Purpose |
| --- | --- |
| `SOURCEPEEK_DISABLE=1` | Turns Sourcepeek off (no tagging, no backend) |
| `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, … | AI features (same keys as in dev) |
| `SOURCEPEEK_GITHUB_TOKEN` | Git history on Vercel. Required for private repos and for "Line changed"; without it the public GitHub API limit (60 requests/hour) applies |
| `SOURCEPEEK_GITHUB_REPO` | `owner/repo`, only needed outside Vercel when there is no `.git` folder |
| `SOURCEPEEK_GITHUB_PATH_PREFIX` | Folder of the app inside the repo, for monorepos |

How it works in production:

- **Next.js** (`next start` and Vercel): `/__sourcepeek/*` is rewritten to the API route. Your source files are bundled into that one function, so the AI features can read them.
- **Vite**: `vite build` + `vite preview`.
- **Git history**: Vercel doesn't deploy the `.git` folder, so commits and blame come from the GitHub API using Vercel's `VERCEL_GIT_*` variables. Elsewhere the local `git` is used when available.

Limits:

- Static exports and Vite apps deployed as static files have no backend, so Sourcepeek stays hidden there.
- Svelte only records element locations in dev builds, so Svelte elements can't be located in production.
- The backend is reachable on every deployment. Anyone who calls `/__sourcepeek/*` (with the `x-sourcepeek` header) can read component source through it and spend your AI credits, even if you don't render `<Sourcepeek />`. Set `SOURCEPEEK_DISABLE=1` on deployments that must not expose it.

## Security

- Endpoints require a custom `x-sourcepeek` header, so other websites you visit can't call them (browsers would need a CORS preflight that is never granted).
- Only source files (`.js .jsx .ts .tsx .mjs .vue .svelte`, plus `.html` templates in Angular projects) outside `node_modules` can be read.
- *Apply to code* only runs on a local dev server, only for requests from this computer, and only writes inside the project (see the safety net above). It never runs in production builds.

## Environment variables

| Variable | Default | Purpose |
| --- | --- | --- |
| `SOURCEPEEK_IDE` | `vscode` | Default editor for Alt+click and *Open in…*: `vscode`, `cursor`, `windsurf`, `vscode-insiders`, `zed`, `webstorm`, `idea`. A choice made in the panel overrides it per browser. |
| `SOURCEPEEK_EDITS` | on | `0` disables *Apply to code*. |
| `SOURCEPEEK_ALLOW_REMOTE_EDITS` | off | `1` allows *Apply to code* from other devices that can reach your dev server. |
| `SOURCEPEEK_AI_PRICE` | built-in for default models | `input,output` in USD per 1M tokens (e.g. `3,15`), used by the **$** spend estimate. |
| `SOURCEPEEK_CALLSITES` | on | `0` stops tagging component usages (disables *Used in* and the call-site context for AI edits). |

## Troubleshooting

- **No button appears.** Check the browser console. `backend not found at /__sourcepeek` means setup didn't run or the dev server wasn't restarted. Run `npx sourcepeek doctor` to see what was detected.
- **Angular: “Could not find the source of this element”.** The element belongs to a component that isn't in your project (a library), or the dev server runs a production configuration (`ng serve --configuration production` has no debug API). Use the default development configuration.
- **Clicking shows nothing for some elements.** Only elements written in your own source files are tagged; elements created inside libraries in `node_modules` are not.
- **Turbopack + JSX in `.js` files.** Under Turbopack, JSX is tagged in `.jsx` and `.tsx` files. Webpack mode also tags `.js`.
- **Disable temporarily.** `SOURCEPEEK_DISABLE=1 npm run dev` (Next.js).
- **“Apply to code” is greyed out.** Hover it to see why: it's only available on a local dev server, for requests from this computer.
- **The AI change broke the page.** Click **Revert change** in the red bar, or **Undo** on the change in *Change with AI*. Both restore the exact previous file.
- **Data looks wrong, but the API is fine.** Check the bottom of the page for the amber *mocks active* bar — a mock you forgot is still answering. *Clear all* removes them.
- **Renders & state says *sampled* (React).** The React DevTools hook wasn't there when React loaded. Add `import 'sourcepeek/react-hook'` as the first import of your entry file.
- **A component warns about an unknown `data-mf-call` prop.** Set `SOURCEPEEK_CALLSITES=0` and let us know which component it was.

## Not supported yet

Nuxt, Create React App, Angular production builds (Angular works on `ng serve`).

## License

MIT
