'use strict';
const fs = require('fs');
const path = require('path');

function envFiles(mode) {
  const m = mode || (process.env.NODE_ENV === 'production' ? 'production' : 'development');
  return [`.env.${m}.local`, '.env.local', `.env.${m}`, '.env'];
}

function readEnv(root, name, mode) {
  if (process.env[name]) return process.env[name];
  for (const f of envFiles(mode)) {
    try {
      const txt = fs.readFileSync(path.join(root, f), 'utf8');
      const m = txt.match(new RegExp(`^\\s*(?:export\\s+)?${name}\\s*=\\s*(.*)\\s*$`, 'm'));
      if (m) {
        const v = m[1].trim();
        const q = v.match(/^(['"`])(.*)\1/);
        return q ? q[2] : v.replace(/\s+#.*$/, '').trim();
      }
    } catch {}
  }
  return null;
}

/**
 * Sourcepeek runs in every environment (dev and production builds) — the app decides where to render <Sourcepeek />.
 * The only off switch is SOURCEPEEK_DISABLE=1 (env or .env file).
 */
function prodEnabled(root, mode) {
  return !/^(true|1|yes|on)$/i.test(String(readEnv(root, 'SOURCEPEEK_DISABLE', mode || 'production') || '').trim());
}

module.exports = { readEnv, prodEnabled };
