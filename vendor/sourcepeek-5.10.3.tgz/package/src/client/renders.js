// "Renders & state": a timeline of one component's renders and what changed in each.
//
// Only the component you opened is tracked, starting when you open the section, and only the last 100 entries
// are kept. "Render" means something different per framework, so each one is labelled for what it really is:
//   • React   — re-renders, from the React DevTools commit hook (exact). Without the hook: sampled.
//   • Vue     — component updates (Vue re-ran the component's render function).
//   • Angular — change detection checks. Angular checks a component on every cycle; that doesn't mean the DOM changed.
//   • Svelte  — changes that reached the component's DOM. Svelte 5 has no runtime component instance to read
//               state from, so this is a rough render count.

import { el, api, copy } from './core.js';
import { findCurrentFiber, readReact, readVue, describe } from './inspect.js';
import { ngRead } from './angular.js';

const MAX_ENTRIES = 100;
const SAMPLE_MS = 250;

const KINDS = {
  react: { title: 'Re-renders', unit: 'render', verb: 'rendered' },
  vue: { title: 'Component updates', unit: 'update', verb: 'updated' },
  angular: { title: 'Change detection checks', unit: 'check', verb: 'checked' },
  svelte: { title: 'DOM updates', unit: 'DOM update', verb: 'DOM updated' },
  dom: { title: 'DOM updates', unit: 'DOM update', verb: 'DOM updated' },
};

const plural = (n, w) => `${n} ${w}${n === 1 ? '' : 's'}`;

function hhmmss(t) {
  const d = new Date(t);
  return [d.getHours(), d.getMinutes(), d.getSeconds()].map((x) => String(x).padStart(2, '0')).join(':');
}

const short = (v) => {
  const s = String(v);
  return s.length > 48 ? s.slice(0, 47) + '…' : s;
};

// ---------- React commit hook (shared, installed once) ----------

const reactBus = { listeners: new Set(), seen: false };

function reactDispatcher() {
  const hook = typeof window !== 'undefined' ? window.__REACT_DEVTOOLS_GLOBAL_HOOK__ : null;
  if (!hook || typeof hook !== 'object') return false;
  const cur = hook.onCommitFiberRoot;
  if (cur && cur.__sourcepeek) return true;
  const wrapped = function onCommitFiberRoot() {
    reactBus.seen = true;
    if (reactBus.listeners.size) {
      for (const fn of reactBus.listeners) {
        try {
          fn();
        } catch {}
      }
    }
    return typeof cur === 'function' ? cur.apply(this, arguments) : undefined;
  };
  wrapped.__sourcepeek = true;
  try {
    hook.onCommitFiberRoot = wrapped;
  } catch {
    return false;
  }
  return true;
}

// ---------- snapshots and diffs ----------
// Each value is kept three ways: the short preview shown in the UI, a deeper fingerprint (so a change nested
// below what the preview shows still counts), and the value itself (so a prop that arrives as a new object or
// function with the same contents — the usual reason a memoised child re-renders — shows up too).

const isObj = (v) => v !== null && (typeof v === 'object' || typeof v === 'function');

function fingerprint(value) {
  let budget = 4000;
  const seen = new WeakSet();
  const walk = (v, depth) => {
    if (--budget < 0) return '…';
    const t = typeof v;
    if (v === null || v === undefined || t === 'boolean' || t === 'number' || t === 'bigint') return String(v);
    if (t === 'string') return JSON.stringify(v.length > 2000 ? v.slice(0, 2000) : v);
    if (t === 'symbol') return v.toString();
    if (t === 'function') return `ƒ${v.name || ''}`;
    if (typeof Node !== 'undefined' && v instanceof Node) return v.nodeType === 1 ? `<${v.tagName}>` : v.nodeName;
    if (v.__v_isRef) return walk(v.value, depth);
    if (seen.has(v)) return '[circular]';
    seen.add(v);
    if (depth > 6) return '{…}';
    try {
      if (v.$$typeof) {
        const type = v.type;
        const name = typeof type === 'string' ? type : (type && (type.displayName || type.name)) || 'C';
        return `<${name} ${v.key == null ? '' : v.key} ${walk(v.props, depth + 1)}>`;
      }
      if (v instanceof Date) return `D${v.getTime()}`;
      if (v instanceof Map) return `M[${[...v].slice(0, 50).map(([k, x]) => walk(k, depth + 1) + '=' + walk(x, depth + 1)).join(',')}]`;
      if (v instanceof Set) return `S[${[...v].slice(0, 50).map((x) => walk(x, depth + 1)).join(',')}]`;
      if (v instanceof Promise) return 'Promise';
      if (Array.isArray(v)) return `[${v.slice(0, 100).map((x) => walk(x, depth + 1)).join(',')}${v.length > 100 ? `,#${v.length}` : ''}]`;
      const keys = Object.keys(v).filter((k) => !k.startsWith('__v_') && !k.startsWith('_'));
      return `{${keys.slice(0, 60).map((k) => `${k}:${walk(v[k], depth + 1)}`).join(',')}}`;
    } catch {
      return '{?}';
    }
  };
  return walk(value, 0);
}

function entry(key, v) {
  return { preview: key === 'children' && Array.isArray(v) ? `[${v.length} children]` : describe(v), deep: fingerprint(v), ref: v };
}

function toMap(rows) {
  const m = new Map();
  for (const [k, v] of rows || []) m.set(k, entry(k, v));
  return m;
}

function snap(props, state) {
  return { props: toMap(props), state: toMap(state) };
}

/** Comparable text of a snapshot (no object references), for the sampled trackers. */
function snapKey(s) {
  return JSON.stringify([[...s.props].map(([k, e]) => [k, e.deep]), [...s.state].map(([k, e]) => [k, e.deep])]);
}

const MISSING = { preview: 'undefined', deep: 'undefined', ref: undefined };

function diff(a, b) {
  const out = [];
  for (const src of ['props', 'state']) {
    const before = a ? a[src] : new Map();
    const after = b[src];
    const keys = new Set([...before.keys(), ...after.keys()]);
    const kind = src === 'props' ? 'prop' : 'state';
    for (const k of keys) {
      const x = before.has(k) ? before.get(k) : MISSING;
      const y = after.has(k) ? after.get(k) : MISSING;
      if (x.preview !== y.preview) out.push({ key: k, from: x.preview, to: y.preview, src: kind });
      else if (x.deep !== y.deep) out.push({ key: k, from: x.preview, to: y.preview, src: kind, nested: true });
      else if (x.ref !== y.ref && isObj(x.ref) && isObj(y.ref)) out.push({ key: k, from: x.preview, to: y.preview, src: kind, ref: true });
    }
  }
  return out;
}

// ---------- per-framework trackers ----------
// Each returns { mode, note, stop } and calls emit(snapshot | { dom: changes }) per render.

function trackReact(fiber, emit, setMode) {
  let last = null;
  const take = (cur) => {
    last = { fiber: cur, props: cur.memoizedProps, state: cur.memoizedState };
    const { props, state } = readReact(cur, true);
    return snap(props, state);
  };
  const start = findCurrentFiber(fiber);
  if (!start) return null;
  const baseline = take(start);
  let gone = false;
  const check = () => {
    if (gone) return;
    let cur = null;
    try {
      cur = findCurrentFiber(fiber);
    } catch {}
    if (!cur) {
      gone = true;
      emit({ unmounted: true });
      return;
    }
    const flags = (cur.flags !== undefined ? cur.flags : cur.effectTag) || 0;
    // PerformedWork (1) is set on a fiber that actually ran this commit; a bailed-out clone has it cleared.
    const rendered = cur.memoizedProps !== last.props || cur.memoizedState !== last.state || (cur !== last.fiber && (flags & 1) === 1);
    if (rendered) emit(take(cur));
  };
  let timer = null;
  const hooked = reactDispatcher();
  const exact = () => {
    clearInterval(timer);
    timer = null;
    setMode('exact', 'Exact: every React commit is checked through the React DevTools hook.');
  };
  const onCommit = () => {
    if (timer) exact();
    check();
  };
  if (hooked) reactBus.listeners.add(onCommit);
  if (hooked && reactBus.seen) exact();
  else {
    timer = setInterval(check, SAMPLE_MS);
    setMode(
      'sampled',
      hooked
        ? 'Waiting for the first React commit… Until then the component is sampled every 250 ms.'
        : 'Sampled every 250 ms — renders between two samples show as one. For exact counts, import "sourcepeek/react-hook" before React (see the README).'
    );
  }
  return {
    baseline,
    stop() {
      clearInterval(timer);
      reactBus.listeners.delete(onCommit);
    },
  };
}

function trackVue(inst, emit, setMode) {
  const take = () => {
    const { props, state } = readVue(inst, true);
    return snap(props, state);
  };
  const baseline = take();
  const fn = () => {
    if (inst.isUnmounted) return emit({ unmounted: true });
    emit(take());
  };
  // `u` holds the instance's `updated` lifecycle hooks; Vue runs them after every update of this component.
  if (!Array.isArray(inst.u)) inst.u = inst.u ? [inst.u] : [];
  inst.u.push(fn);
  setMode('exact', 'Each entry is one update: Vue re-ran this component’s render because something it uses changed.');
  return {
    baseline,
    stop() {
      if (Array.isArray(inst.u)) {
        const i = inst.u.indexOf(fn);
        if (i >= 0) inst.u.splice(i, 1);
      }
    },
  };
}

function trackAngular(inst, emit, setMode) {
  let onPush = false;
  const take = () => {
    const r = ngRead(inst, true);
    onPush = r.onPush;
    return snap(r.props, r.state);
  };
  const baseline = take();
  const bridge = typeof window !== 'undefined' ? window.__SOURCEPEEK_NG__ : null;
  const pushNote = onPush ? ' This component is OnPush, so Angular may have skipped some of these cycles — treat the count as an upper bound.' : '';
  if (bridge && bridge.listeners) {
    const fn = () => emit(take());
    bridge.listeners.add(fn);
    setMode('exact', `One entry per change detection cycle. Angular checks the component's bindings each cycle; a check doesn't mean anything re-rendered.${pushNote}`);
    return { baseline, stop: () => bridge.listeners.delete(fn) };
  }
  let last = null;
  const timer = setInterval(() => {
    const s = take();
    const key = snapKey(s);
    if (key !== last) {
      last = key;
      emit(s);
    }
  }, SAMPLE_MS);
  last = snapKey(baseline);
  setMode('sampled', 'Change detection cycles can’t be counted here (add provideSourcepeek() to your providers). Showing value changes, sampled every 250 ms.');
  return { baseline, stop: () => clearInterval(timer) };
}

function nodeLabel(n) {
  if (!n) return '';
  if (n.nodeType === 3) return 'text';
  return n.nodeType === 1 ? `<${n.tagName.toLowerCase()}>` : n.nodeName;
}

function trackDom(root, emit, setMode, svelte) {
  if (!root || typeof MutationObserver === 'undefined') return null;
  const mo = new MutationObserver((records) => {
    const changes = [];
    let added = 0;
    let removed = 0;
    for (const r of records) {
      if (r.type === 'characterData') {
        const to = r.target.textContent;
        if (r.oldValue !== to) changes.push({ key: `text in ${nodeLabel(r.target.parentElement)}`, from: JSON.stringify(r.oldValue), to: JSON.stringify(to), src: 'dom' });
      } else if (r.type === 'attributes') {
        if (/^data-mf-|^__/.test(r.attributeName)) continue;
        const to = r.target.getAttribute(r.attributeName);
        if (r.oldValue !== to) changes.push({ key: `${nodeLabel(r.target)} ${r.attributeName}`, from: r.oldValue == null ? '—' : JSON.stringify(r.oldValue), to: to == null ? '—' : JSON.stringify(to), src: 'dom' });
      } else {
        added += r.addedNodes.length;
        removed += r.removedNodes.length;
      }
    }
    if (added || removed) changes.push({ key: 'nodes', from: '', to: `+${added} / −${removed}`, src: 'dom', nodes: true });
    if (!root.isConnected) return emit({ unmounted: true });
    if (changes.length) emit({ dom: changes.slice(0, 12) });
  });
  mo.observe(root, { subtree: true, childList: true, attributes: true, attributeOldValue: true, characterData: true, characterDataOldValue: true });
  setMode(
    'rough',
    svelte
      ? 'Svelte 5 has no runtime component instance, so its state can’t be read from outside. Each entry is a change that reached this component’s DOM — a rough render count, and only renders that changed something.'
      : 'No framework instance found for this element. Each entry is a change in its DOM.'
  );
  return { baseline: null, stop: () => mo.disconnect() };
}

/** The outermost element written in the same Svelte file as `node`. */
function svelteRoot(node, file) {
  let top = node;
  for (let a = node; a && a.nodeType === 1; a = a.parentElement) {
    const m = a.__svelte_meta;
    if (m && m.loc && m.loc.file === file) top = a;
  }
  return top;
}

export function trackKind(track) {
  if (!track) return 'dom';
  if (track.fiber) return 'react';
  if (track.vueInst) return 'vue';
  if (track.ngInst) return 'angular';
  if (track.el && track.el.__svelte_meta) return 'svelte';
  return 'dom';
}

// ---------- UI ----------

/**
 * Fill the "Renders & state" accordion body. ctx: { componentName, file, track: { fiber|vueInst|ngInst, el, file, name } }.
 * Returns a cleanup function that stops tracking.
 */
export function buildRenders(box, ctx) {
  const track = ctx.track || {};
  const kind = trackKind(track);
  const K = KINDS[kind];
  let timer = null;
  const state = { n: 0, nothing: 0, entries: [], paused: false, names: null, since: Date.now(), current: null, mode: '', note: '', ended: false };

  const head = el('div', 'mf-rs-head');
  const stats = el('div', 'mf-rs-stats');
  const pauseBtn = el('button', 'mf-net-btn', 'Pause');
  pauseBtn.type = 'button';
  const clearBtn = el('button', 'mf-net-btn', 'Clear');
  clearBtn.type = 'button';
  const copyBtn = el('button', 'mf-net-btn', 'Copy');
  copyBtn.type = 'button';
  copyBtn.title = 'Copy the timeline as text';
  head.append(stats, pauseBtn, clearBtn, copyBtn);
  const modeLine = el('div', 'mf-rs-mode');
  const current = el('details', 'mf-kv mf-rs-current');
  const list = el('ol', 'mf-rs-list');
  box.append(head, modeLine, current, list);

  const setMode = (mode, note) => {
    state.mode = mode;
    state.note = note;
    schedule();
  };

  // React hooks have no names at runtime — ask the backend for `const [name, setName] = useState()` order.
  if (kind === 'react' && (track.file || ctx.file) && track.name) {
    api('/state-names', { file: track.file || ctx.file, componentName: track.name }).then((res) => {
      if (res.ok && res.data && res.data.names && res.data.names.length) {
        state.names = res.data.names;
        schedule();
      }
    });
  }
  const label = (key) => {
    const m = state.names && /^state\[(\d+)\]$/.exec(key);
    return m && state.names[Number(m[1])] ? state.names[Number(m[1])] : key;
  };

  const push = (entry) => {
    state.entries.push(entry);
    if (state.entries.length > MAX_ENTRIES) state.entries.splice(0, state.entries.length - MAX_ENTRIES);
  };

  const emit = (s) => {
    if (state.ended) return;
    if (s.unmounted) {
      state.ended = true;
      push({ n: null, t: Date.now(), unmounted: true });
      stop();
      return schedule();
    }
    if (state.paused) {
      if (s.props) state.current = s;
      return;
    }
    state.n++;
    const t = Date.now();
    let changes;
    if (s.dom) changes = s.dom;
    else {
      changes = diff(state.current, s);
      state.current = s;
    }
    if (!changes.length) {
      state.nothing++;
      const last = state.entries[state.entries.length - 1];
      if (last && last.nothing && !last.unmounted) {
        last.count++;
        last.nTo = state.n;
        last.t = t;
      } else push({ n: state.n, nTo: state.n, t, nothing: true, count: 1 });
    } else {
      // Only new references (same values): the render could have been skipped, so it counts as "nothing changed".
      const refOnly = changes.every((c) => c.ref);
      if (refOnly) state.nothing++;
      push({ n: state.n, t, changes, refOnly });
    }
    schedule();
  };

  let tracker = null;
  try {
    if (kind === 'react') tracker = trackReact(track.fiber, emit, setMode);
    else if (kind === 'vue') tracker = trackVue(track.vueInst, emit, setMode);
    else if (kind === 'angular') tracker = trackAngular(track.ngInst, emit, setMode);
    else tracker = trackDom(kind === 'svelte' ? svelteRoot(track.el, track.file || ctx.file) : track.el, emit, setMode, kind === 'svelte');
  } catch {
    tracker = null;
  }
  if (tracker && tracker.baseline) state.current = tracker.baseline;
  if (!tracker) setMode('off', `Couldn’t attach to ${ctx.componentName} — it may have unmounted. Inspect the element again.`);

  function schedule() {
    if (timer) return;
    timer = setTimeout(() => {
      timer = null;
      render();
    }, 80);
  }

  function changeText(c) {
    if (c.nodes) return `nodes ${c.to}`;
    const tag = c.src === 'dom' ? '' : ` (${c.src})`;
    if (c.ref) return `${label(c.key)} new reference, same value${tag}`;
    if (c.nested) return `${label(c.key)} changed inside ${short(c.to)}${tag}`;
    return `${label(c.key)} ${short(c.from)} → ${short(c.to)}${tag}`;
  }

  function lineText(e) {
    if (e.unmounted) return `${hhmmss(e.t)} · unmounted — tracking stopped`;
    if (e.nothing) {
      const range = e.count > 1 ? `#${e.n}–#${e.nTo}` : `#${e.n}`;
      return `${range} · ${hhmmss(e.t)} · ${e.count > 1 ? `${e.count}× ` : ''}${K.verb}, nothing changed`;
    }
    return [`#${e.n}`, hhmmss(e.t), ...e.changes.map(changeText)].join(' · ');
  }

  function renderCurrent() {
    const open = current.open;
    current.textContent = '';
    const s = state.current;
    const rows = s ? [...[...s.props].map(([k, v]) => ['prop', k, v.preview]), ...[...s.state].map(([k, v]) => ['state', label(k), v.preview])] : [];
    current.appendChild(el('summary', 'mf-section-title', `Current values (${rows.length})`));
    const kv = el('div', 'mf-kv-list');
    if (!rows.length) kv.appendChild(el('div', 'mf-muted', kind === 'svelte' || kind === 'dom' ? 'Not readable for this component.' : 'No props or state.'));
    for (const [src, k, v] of rows.slice(0, 60)) {
      const r = el('div', 'mf-kv-row');
      r.append(el('span', 'mf-kv-key', k), el('span', 'mf-rs-src', src), el('code', 'mf-kv-val', v));
      kv.appendChild(r);
    }
    current.appendChild(kv);
    current.open = open;
  }

  function render() {
    if (!box.isConnected && box.dataset.mfRendered) return;
    box.dataset.mfRendered = '1';
    const nothing = state.nothing;
    stats.textContent = '';
    stats.append(el('strong', null, plural(state.n, K.unit)), document.createTextNode(` since ${hhmmss(state.since)}`));
    if (state.n) {
      const w = el('span', nothing ? 'mf-rs-wasted' : 'mf-muted', ` · ${nothing} with nothing changed`);
      if (nothing) w.title = kind === 'angular' ? 'Normal for Angular: every cycle checks the component.' : 'Renders where no prop or state value changed (at most new object/function references) — candidates for memo, useCallback / useMemo.';
      stats.appendChild(w);
    }
    modeLine.textContent = '';
    modeLine.append(el('span', 'mf-rs-kind', K.title), el('span', 'mf-badge mf-rs-mode--' + state.mode, state.mode === 'exact' ? 'exact' : state.mode === 'sampled' ? 'sampled' : state.mode === 'rough' ? 'rough' : 'off'));
    if (state.note) modeLine.appendChild(el('span', 'mf-muted', state.note));
    renderCurrent();
    list.textContent = '';
    if (!state.entries.length) {
      list.appendChild(el('li', 'mf-muted mf-rs-empty', state.paused ? 'Paused.' : `No ${K.unit}s yet. Use the page — every ${K.unit} of ${ctx.componentName} shows up here.`));
    }
    for (const e of state.entries.slice().reverse()) {
      const li = el('li', 'mf-rs-row' + (e.nothing || e.refOnly ? ' mf-rs-row--nothing' : '') + (e.unmounted ? ' mf-rs-row--end' : ''));
      if (e.unmounted) {
        li.append(el('span', 'mf-rs-time', hhmmss(e.t)), el('span', null, 'Unmounted — tracking stopped. Inspect the element again to follow the new instance.'));
      } else {
        li.append(el('span', 'mf-rs-n', e.nothing && e.count > 1 ? `#${e.n}–${e.nTo}` : `#${e.n}`), el('span', 'mf-rs-time', hhmmss(e.t)));
        if (e.nothing) li.appendChild(el('span', 'mf-rs-nothing', `${e.count > 1 ? `${e.count}× ` : ''}${K.verb}, nothing changed`));
        else {
          const chips = el('span', 'mf-rs-changes');
          for (const c of e.changes) {
            const chip = el('span', 'mf-rs-change mf-rs-change--' + c.src + (c.ref ? ' mf-rs-change--ref' : ''));
            const srcTag = el('span', 'mf-rs-src', c.src === 'dom' ? '' : c.src);
            if (c.nodes) chip.textContent = `nodes ${c.to}`;
            else if (c.ref) {
              chip.append(el('b', null, label(c.key)), document.createTextNode(' new reference, same value'), srcTag);
              chip.title = `${label(c.key)} is a new ${typeof c.to === 'string' && c.to.startsWith('ƒ') ? 'function' : 'object'} with the same contents.\nThis alone re-renders memo() children — wrap it in useCallback / useMemo, or compare by value.`;
            } else if (c.nested) {
              chip.append(el('b', null, label(c.key)), document.createTextNode(` changed inside ${short(c.to)}`), srcTag);
              chip.title = `${label(c.key)}: a value nested deeper than the preview shows changed.\n${c.to}`;
            } else chip.append(el('b', null, label(c.key)), document.createTextNode(` ${short(c.from)} → ${short(c.to)}`), srcTag);
            if (!c.ref && !c.nested) chip.title = c.nodes ? '' : `${label(c.key)}\n${c.from}\n→ ${c.to}`;
            chips.appendChild(chip);
          }
          li.appendChild(chips);
        }
      }
      list.appendChild(li);
    }
    if (state.n > MAX_ENTRIES && state.entries.length >= MAX_ENTRIES) list.appendChild(el('li', 'mf-muted mf-rs-empty', `Only the last ${MAX_ENTRIES} entries are kept.`));
  }

  pauseBtn.onclick = () => {
    state.paused = !state.paused;
    pauseBtn.textContent = state.paused ? 'Resume' : 'Pause';
    schedule();
  };
  clearBtn.onclick = () => {
    state.entries = [];
    state.n = 0;
    state.nothing = 0;
    state.since = Date.now();
    schedule();
  };
  copyBtn.onclick = () => {
    const lines = [`${ctx.componentName} — ${K.title} (${state.mode}), since ${hhmmss(state.since)}`, ...state.entries.map(lineText)];
    copy(lines.join('\n'), copyBtn);
  };

  function stop() {
    if (tracker) tracker.stop();
    tracker = null;
  }

  render();
  return () => {
    clearTimeout(timer);
    stop();
  };
}
