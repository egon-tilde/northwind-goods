import handlerMod from './server/handler.cjs';

const { handle, routeFromUrl, readBody, send } = handlerMod;

export default async function sourcepeekApi(req, res) {
  const [status, obj] = await handle({
    method: req.method,
    route: routeFromUrl(req.url) || '',
    headers: req.headers,
    getBody: () => readBody(req),
    root: process.cwd(),
  });
  send(res, status, obj);
}
